folder( "Bootcamp - Cartridge" ){
}

def folder = "Bootcamp - Cartridge"



def generatejob = folder + "/Build Job"
freeStyleJob(generatejob){

    steps{
		scm{
			git{
				remote{
					name('Simple Web-app from sir Ren')
					url('https://github.com/markuibanez/Bootcamp-GitHub-noReadme.git')
					credentials('6075f739-750f-4495-bf5e-5f88fc0f706d')
				}
			}
		}

		maven{
			mavenInstallation('MAVEN_HOME')
			goals('package')
		}
		
		wrappers {
			preBuildCleanup {
				includePattern('**/target/**')
				deleteDirectories()
				cleanupParameter('CLEANUP')
			}
		}
		
		publishers {
			downstreamParameterized {
				trigger('Code Analysis') {
					condition('SUCCESS')
					parameters {
						predefinedProp('CUSTOM_WORKSPACE', '${WORKSPACE}')
						predefinedProp('CUSTOM_BUILD_ID', '${BUILD_ID}')
					}
				}
			}
		}
	}
}




def generatejob2 = folder + "/Code Analysis"
freeStyleJob(generatejob2){

	steps{
		parameters {
			stringParam('CUSTOM_WORKSPACE')
			stringParam('CUSTOM_BUILD_ID')
		}
	
		customWorkspace('${CUSTOM_WORKSPACE}')
		
		batchFile('mvn sonar:sonar')
	
		publishers {
			downstreamParameterized {
				trigger('Upload to Nexus') {
					condition('SUCCESS')
					parameters {
						predefinedProp('CUSTOM_WORKSPACE', '${WORKSPACE}')
						predefinedProp('CUSTOM_BUILD_ID', '${BUILD_ID}')
					}
				}
			}
		}
	}
}



def generatejob3 = folder + "/Upload to Nexus"
freeStyleJob(generatejob3){
	
	steps{
		parameters {
			stringParam('CUSTOM_WORKSPACE')
			stringParam('CUSTOM_BUILD_ID')
		}
		
		customWorkspace('${CUSTOM_WORKSPACE}')
		
		 shell('echo "Sorry, I dont know the DSL script for Nexus Repository Manager Publisher"')
	}
}
	

def generatepipeview = folder + "/Bootcamp - Cartridge Pipeline View"
buildPipelineView(generatepipeview) {
    title('Bootcamp - Cartridge Pipeline View')
    selectedJob(generatejob)
    alwaysAllowManualTrigger()
    displayedBuilds(1)
}