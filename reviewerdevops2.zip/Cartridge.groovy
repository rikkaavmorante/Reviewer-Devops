folder( "AverageWebApp" ){
}

def folder = "AverageWebApp"



def generatejob = folder + "/Build_Job"
freeStyleJob(generatejob){

    steps{
		scm{
			git{
				branch('*/master')
				remote{
					url('git@gitlab:4R1C/AverageWebApp.git')
					credentials('adop-jenkins-master')
				}
				extensions{
					cleanAfterCheckout()
				}
			}
		}
		triggers{
			 gitlabPush {
				buildOnMergeRequestEvents(true)
				buildOnPushEvents(true)
				enableCiSkip(true)
				setBuildDescription(true)
				rebuildOpenMergeRequest('never')
			}
		}

		maven{
			mavenInstallation('ADOP Maven')
			goals('package')
		}
		
		wrappers {
			preBuildCleanup {
				includePattern('**/target/**')
				deleteDirectories()
				cleanupParameter('CLEANUP')
			}
		}
		
		publishers{
			extendedEmail {
				recipientList('4r1c4r1c@gmail.com')
				replyToList('$DEFAULT_REPLYTO')
				defaultContent('$DEFAULT_CONTENT')
					triggers{
						always{
							attachBuildLog(true)
							content('$PROJECT_DEFAULT_CONTENT')
							sendTo{
								recipientList()
							}
						}	
					}
			}
			downstreamParameterized {
				trigger('Code_Analysis') {
					condition('SUCCESS')
					parameters {
						predefinedProp('CUSTOM_WORKSPACE', '$WORKSPACE')
						predefinedProp('CUSTOM_BUILD_ID', '$BUILD_ID')
					}
				}
			}
		}
	}
}

def generatejob2 = folder + "/Code_Analysis"
freeStyleJob(generatejob2){

	steps{
		parameters {
			stringParam('CUSTOM_WORKSPACE')
			stringParam('CUSTOM_BUILD_ID')
		}
		configure {
			it / 'builders' << 'hudson.plugins.sonar.SonarRunnerBuilder' {
			properties 'sonar.projectKey=AverageWebApp\nsonar.projectVersion=$CUSTOM_BUILD_ID\nsonar.projectName=Web App Average\nsonar.web.url=http://localhost:9000\nsonar.sources=.'
			javaOpts ''
			jdk '(Inherit From Job)'
			project ''
			task ''
			}
		}
		publishers{
		downstreamParameterized {
				trigger('Deploy') {
					condition('SUCCESS')
					parameters {
						predefinedProp('CUSTOM_WORKSPACE', '$WORKSPACE')
						predefinedProp('CUSTOM_BUILD_ID', '$BUILD_ID')
					}
				}
			}
		}
	}
}

def generatejob3 = folder + "/Deploy"
freeStyleJob(generatejob3){
	steps
	{
		scm
		{
			git
			{
			
			}
		}
		publishers{
			downstreamParameterized {
				trigger('SeleniumTest') {
					condition('SUCCESS')
					parameters {
						predefinedProp('CUSTOM_WORKSPACE', '$WORKSPACE')
						predefinedProp('CUSTOM_BUILD_ID', '$BUILD_ID')
					}
				}
			}
		}
	}
}

def generatejob4 = folder + "/SeleniumTest"
freeStyleJob(generatejob4)
{
	steps
	{
		parameters {
			stringParam('CUSTOM_WORKSPACE')
			stringParam('CUSTOM_BUILD_ID')
		}
		scm
		{
			git
			{
				branch('*/master')
				remote
				{
					url('git@gitlab:4R1C/SeleniumTest.git')
					credentials('bf5ad93f-1751-4724-853d-0dc3c0ab6486')
				}
			}
		}

		shell("java -jar SeleniumTestver1.jar")
		
		publishers{
			downstreamParameterized {
				trigger('Upload_Artifact') {
					condition('SUCCESS')
					parameters {
						predefinedProp('CUSTOM_WORKSPACE', '$WORKSPACE')
						predefinedProp('CUSTOM_BUILD_ID', '$BUILD_ID')
					}
				}
			}
		}
	}
}



def generatejob5= folder + "/Upload_Artifact"
freeStyleJob(generatejob5)
{
	steps
	{
		parameters {
			stringParam('CUSTOM_WORKSPACE')
			stringParam('CUSTOM_BUILD_ID')
		}
		scm
		{
			git
			{
				branch('*/master')
				remote
				{
					url('git@gitlab:4R1C/AverageWebApp.git')
					credentials('adop-jenkins-master')
				}
			}
		}

		maven
		{
			mavenInstallation('ADOP Maven')
			goals('clean verify')
			rootPOM('$workspace/pom.xml')
		}

		nexusArtifactUploader
		{
        	nexusVersion('NEXUS')
        	protocol('HTTP')
        	nexusUrl('13.56.92.148/nexus/content/repositories/releases/')
        	groupId('4R1C')
        	version('1.0')
        	credentialsId('bf5ad93f-1751-4724-853d-0dc3c0ab6486')
        	repository('Releases')

        	artifact
        	{
            	artifactId('webapp')
            	type('war')
            	classifier('')
            	file('/var/jenkins_home/jobs/AverageWebApp/jobs/Build_Job/workspace/target/webapp.war')
        	}
        }
	}
} 